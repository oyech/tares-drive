-- AlterTable
ALTER TABLE "files" ADD COLUMN     "password" VARCHAR;
