export const VERSION = '2.5.2'
export const MAX_UPLOAD_SIZE = 2_000_000_000
export const CHUNK_SIZE = 512 * 1024
export const RETRY_COUNT = 50